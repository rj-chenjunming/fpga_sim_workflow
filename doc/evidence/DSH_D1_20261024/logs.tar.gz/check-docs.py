from pathlib import Path
import importlib.util
import re
import subprocess
import sys
import tempfile

root = Path.cwd()
spec = importlib.util.spec_from_file_location('doccheck', root / 'doc/audit/check_doc_links.py')
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)
roots = module.default_roots()
with tempfile.TemporaryDirectory(prefix='ai-panel-doc-base-') as directory:
    baseline = Path(directory)
    for file in subprocess.check_output(['git', 'ls-tree', '-rz', '--name-only', 'HEAD']).decode().split('\0'):
        if not file.endswith('.md'):
            continue
        destination = baseline / file
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(subprocess.check_output(['git', 'show', 'HEAD:' + file]))
    before = module.scan(roots, baseline)
    after = module.scan(roots)
    for kind in ['missing', 'env_missing', 'known_missing']:
        added = {(item.doc, item.token) for item in getattr(after, kind)} - {
            (item.doc, item.token) for item in getattr(before, kind)}
        print(kind, 'baseline=' + str(len(getattr(before, kind))),
              'current=' + str(len(getattr(after, kind))), 'added=' + str(len(added)))
        assert not added, sorted(added)
    print('doc_check_exit=' + str(after.exit_code))
    paths = set(subprocess.check_output(['git', 'diff', '--name-only', '-z', 'HEAD']).decode().split('\0'))
    paths.update(subprocess.check_output(['git', 'ls-files', '-z', '--others', '--exclude-standard']).decode().split('\0'))
    for file in sorted(paths):
        if not file.endswith('.md'):
            continue
        path = root / file
        current = path.read_text()
        old = baseline / file
        previous = old.read_text() if old.exists() else ''
        assert len(re.findall(r'^```', current, re.M)) % 2 == 0, file
        links = set(re.findall(r'\[[^\]]*\]\(([^)]+)\)', current)) - set(re.findall(r'\[[^\]]*\]\(([^)]+)\)', previous))
        for link in links:
            if re.match(r'^[a-zA-Z]+:', link) or link.startswith('#'):
                continue
            target = link.split('#')[0].strip('<>')
            assert not target or (path.parent / target).exists(), (file, target)
    print('new_relative_links_and_fences=pass')
