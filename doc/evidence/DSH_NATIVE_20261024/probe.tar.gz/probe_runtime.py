"""Bounded local runtime checks. Never prompts a model or prints startup credentials."""
import asyncio
import http.client
import json
import os
from pathlib import Path
import re
import signal
from urllib.parse import urlsplit

ROOT = Path(__file__).resolve().parent
CLI = ROOT / 'node_modules/.bin/dsh'
ENV = dict(os.environ, DSH_HOME=str(ROOT / 'home'),
           DSH_AGENTS_HOME=str(ROOT / 'agents'), DSH_TELEMETRY_MODE='DISABLED')


async def spawn(*args):
    return await asyncio.create_subprocess_exec(str(CLI), *args, cwd=ROOT / 'workspace',
        env=ENV, stdin=asyncio.subprocess.PIPE, stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE, start_new_session=True)


async def drain(stream, facts):
    while line := await stream.readline():
        facts['diagnostic_lines'] = facts.get('diagnostic_lines', 0) + 1
        # Record fixed categories only; diagnostic text may contain credentials.
        for category in ['ERR_MODULE_NOT_FOUND', 'MODULE_NOT_FOUND', 'EACCES', 'EADDRINUSE']:
            if category.encode() in line:
                facts.setdefault('diagnostic_categories', []).append(category)


async def stop(process, facts):
    if process.returncode is None:
        os.killpg(process.pid, signal.SIGTERM)
    try:
        await asyncio.wait_for(process.wait(), 10)
    except asyncio.TimeoutError:
        facts['forced_kill'] = True
        os.killpg(process.pid, signal.SIGKILL)
        await process.wait()
    facts['exit_code'] = process.returncode
    try:
        os.killpg(process.pid, 0)
    except ProcessLookupError:
        facts['process_group_absent'] = True
    else:
        facts['process_group_absent'] = False
        os.killpg(process.pid, signal.SIGKILL)


async def sdk():
    facts = {'profile': 'sdk', 'model_prompt_sent': False}
    p = await spawn('--profile', 'sdk')
    stderr = asyncio.create_task(drain(p.stderr, facts))
    async def rpc(identifier, method, params):
        p.stdin.write((json.dumps({'jsonrpc': '2.0', 'id': identifier,
                                  'method': method, 'params': params}) + '\n').encode())
        await p.stdin.drain()
        while True:
            line = await asyncio.wait_for(p.stdout.readline(), 40)
            if not line:
                raise EOFError('runtime exited before response')
            frame = json.loads(line)
            if frame.get('id') == identifier:
                return frame
    try:
        frame = await rpc(1, 'initialize', {'cwd': str(ROOT / 'workspace'),
            'provider': 'deepseek-official', 'model': 'deepseek-flash'})
        facts['initialize_ok'] = 'result' in frame
        if 'result' in frame:
            info = frame['result'].get('serverInfo', {})
            facts['expected_server_identity'] = info.get('name') == 'deepseek-harness-sdk-runtime'
            facts['protocol_version'] = info.get('version')
        else:
            facts['initialize_error_code'] = frame.get('error', {}).get('code')
        frame = await rpc(2, 'session/wait', {'sessionId': 'd0-nonexistent-session'})
        facts['unknown_session_rejected'] = 'error' in frame
        frame = await rpc(3, 'shutdown', {})
        facts['shutdown_ack'] = frame.get('result') == {}
        await asyncio.wait_for(p.wait(), 10)
    except Exception as exc:
        facts['probe_failure_type'] = type(exc).__name__
    finally:
        await stop(p, facts)
        await stderr
    return facts


async def web():
    facts = {'profile': 'web', 'model_prompt_sent': False}
    p = await spawn('web', '--no-open', '--host', '127.0.0.1', '--port', '0')
    stderr = asyncio.create_task(drain(p.stderr, facts))
    try:
        async def ready():
            while line := await p.stdout.readline():
                match = re.search(rb'dsh web:\s*(https?://\S+)', line)
                if match:
                    url = urlsplit(match.group(1).decode())
                    if url.hostname != '127.0.0.1':
                        raise ValueError('unexpected bind address')
                    return url.port
            raise EOFError('web exited before readiness')
        port = await asyncio.wait_for(ready(), 45)
        facts['ready'] = True
        connection = http.client.HTTPConnection('127.0.0.1', port, timeout=5)
        connection.request('GET', '/')
        response = connection.getresponse()
        body = response.read()
        facts['http_status'] = response.status
        facts['html_document'] = b'<html' in body.lower()
        connection.close()
    except Exception as exc:
        facts['probe_failure_type'] = type(exc).__name__
    finally:
        await stop(p, facts)
        await stderr
    return facts


async def main():
    for name, check in [('sdk', sdk), ('web', web)]:
        facts = await check()
        (ROOT / 'probe-evidence' / (name + '.json')).write_text(json.dumps(facts, indent=2) + '\n')
        print(json.dumps(facts), flush=True)


asyncio.run(main())
